// TRIFAN BOGDAN-CRISTIAN, 312 CD, SEMIGRUPA I
// TEMA 3 - S.D.A.
#ifndef __TASK2_H__
#define __TASK2_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structuri.h"

void solve_task_two(FILE * fin, FILE * fout);

#endif
