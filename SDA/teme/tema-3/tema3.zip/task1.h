// TRIFAN BOGDAN-CRISTIAN, 312 CD, SEMIGRUPA I
// TEMA 3 - S.D.A.
#ifndef __TASK1_H__
#define __TASK1_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structuri.h"

void solve_task_one(FILE * fin, FILE * fout);

#endif
